  
  function showContent() {

          if(document.getElementById("cricket").checked)
          {
            // document.getElementById("hobbyDescp").innerHTML="I Love Cricket."
            document.getElementById("musicDescp").style.display="none";
            document.getElementById("codingDescp").style.display="none";
            document.getElementById("cricketDescp").style.display="block";
          }
          if(document.getElementById("music").checked)
          {
            // document.getElementById("hobbyDescp").innerHTML="I love music."
            document.getElementById("codingDescp").style.display="none";
            document.getElementById("cricketDescp").style.display="none";
            document.getElementById("musicDescp").style.display="block";
          }
           if(document.getElementById("coding").checked)
          {
            // document.getElementById("hobbyDescp").innerHTML="I love music."
            document.getElementById("musicDescp").style.display="none";
            document.getElementById("cricketDescp").style.display="none";
            document.getElementById("codingDescp").style.display="block";
          }
      }